import User from '#models/User.js';
import Account from "#models/Account.js";
import bcrypt from 'bcrypt';
import mongoose from 'mongoose';
import { formatUserDates } from "#helpers/data.reducer.js";
import { successResponse, errorResponse } from "#utils/response.helper.js";
import { clearAuthCookie } from "#utils/cookie.helper.js";
import {
    validateEmail,
    validatePhone,
    validatePassword,
    validateName,
    validateDate,
    validateEnum,
    validateString,
    validateRequiredFields
} from "#utils/validators.js";

export const getProfile = asyncHandler(
    async (req, res) => {
        const { userId } = req.user;

        const [user] = await User.aggregate([
            { $match: { _id: new mongoose.Types.ObjectId(userId) } },
            {
                $lookup: {
                    from: "organizations",
                    localField: "organizationId",
                    foreignField: "_id",
                    pipeline: [{ $project: { name: 1, type: 1 } }],
                    as: "organization"
                }
            },
            { $unwind: { path: "$organization", preserveNullAndEmptyArrays: true } },
            {
                $lookup: {
                    from: "teams",
                    localField: "teamId",
                    foreignField: "_id",
                    pipeline: [{ $project: { teamName: 1, description: 1 } }],
                    as: "team"
                }
            },
            { $unwind: { path: "$team", preserveNullAndEmptyArrays: true } }
        ]);

        if (!user) return errorResponse(res, "User not found", 404);

        return successResponse(res, "Profile fetched", formatUserDates(user));
    }, "USER_GET_PROFILE_ERROR"
);

export const updateProfile = asyncHandler(
    async (req, res) => {
        const { userId } = req.user;

        const user = await User.findById(userId);
        if (!user) return errorResponse(res, "User not found", 404);

        const updates = {};

        if (req.body.name !== undefined) {
            const nameValidation = validateName(req.body.name);
            if (!nameValidation.valid) return errorResponse(res, nameValidation.error);
            updates.name = nameValidation.normalized;
        }

        if (req.body.phone !== undefined) {
            const phoneValidation = validatePhone(req.body.phone);
            if (!phoneValidation.valid) return errorResponse(res, phoneValidation.error);
            const existingPhone = await User.findOne({
                phone: phoneValidation.normalized,
                _id: { $ne: userId }
            });
            if (existingPhone) return errorResponse(res, "Phone number already in use", 409);
            updates.phone = phoneValidation.normalized;
        }

        if (req.body.gender !== undefined) {
            const genderValidation = validateEnum(req.body.gender, ["male", "female", "other"], "Gender");
            if (!genderValidation.valid) return errorResponse(res, genderValidation.error);
            updates.gender = genderValidation.normalized;
        }

        if (req.body.dob !== undefined) {
            const dobValidation = validateDate(req.body.dob, "Date of birth", { noFuture: true, minAge: 18 });
            if (!dobValidation.valid) return errorResponse(res, dobValidation.error);
            updates.dob = dobValidation.normalized;
        }

        if (req.body.address !== undefined) {
            const addressValidation = validateString(req.body.address, "Address", { maxLength: 500 });
            if (!addressValidation.valid) return errorResponse(res, addressValidation.error);
            updates.address = addressValidation.normalized;
        }

        if (req.body.profileImage !== undefined) {
            const profileImageValidation = validateString(req.body.profileImage, "Profile image", { maxLength: 500 });
            if (!profileImageValidation.valid) return errorResponse(res, profileImageValidation.error);
            updates.profileImage = profileImageValidation.normalized;
        }

        if (Object.keys(updates).length === 0) return errorResponse(res, "No valid fields to update");

        const updatedUser = await User.findByIdAndUpdate(userId, updates, { new: true, runValidators: true });

        return successResponse(res, "Profile updated successfully", formatUserDates(updatedUser));
    }, "USER_UPDATE_PROFILE_ERROR"
);

export const changePassword = asyncHandler(
    async (req, res) => {
        const { userId } = req.user;
        const { currentPassword, newPassword } = req.body;

        const requiredCheck = validateRequiredFields(
            { currentPassword, newPassword },
            ['currentPassword', 'newPassword']
        );
        if (!requiredCheck.valid) return errorResponse(res, requiredCheck.error);

        const passwordValidation = validatePassword(newPassword);
        if (!passwordValidation.valid) return errorResponse(res, passwordValidation.error);

        const user = await User.findById(userId);
        if (!user) return errorResponse(res, "User not found", 404);

        const account = await Account.findOne({ email: user.email, role: "user" });
        if (!account) return errorResponse(res, "Account not found", 404);

        const isMatch = await bcrypt.compare(currentPassword, account.password);
        if (!isMatch) return errorResponse(res, "Current password is incorrect", 401);

        const isSamePassword = await bcrypt.compare(newPassword, account.password);
        if (isSamePassword) return errorResponse(res, "New password cannot be the same as current password");

        account.password = await bcrypt.hash(newPassword, 10);
        await account.save();

        return successResponse(res, "Password changed successfully");
    }, "USER_CHANGE_PASSWORD_ERROR"
);

export const deactivateAccount = asyncHandler(
    async (req, res) => {
        const { userId } = req.user;
        const { password } = req.body;

        if (!password) return errorResponse(res, "Password is required to deactivate account");

        const user = await User.findById(userId);
        if (!user) return errorResponse(res, "User not found", 404);

        const account = await Account.findOne({ email: user.email, role: "user" });
        if (!account) return errorResponse(res, "Account not found", 404);

        const isMatch = await bcrypt.compare(password, account.password);
        if (!isMatch) return errorResponse(res, "Invalid password", 401);

        user.isActive = false;
        await user.save();

        // const isSecure = req.secure || req.headers['x-forwarded-proto'] === 'https';
        // res.clearCookie("accessToken", {
        //     httpOnly: true,
        //     secure: isSecure,
        //     sameSite: isSecure ? "none" : "lax",
        //     path: "/"
        // });
        clearAuthCookie(res, req);

        return successResponse(res, "Account deactivated successfully");
    }, "USER_DEACTIVATE_ACCOUNT_ERROR"
);
